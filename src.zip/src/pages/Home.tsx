type HomeProps = {
  onNewCustomer: () => void;
  onAddJob: () => void;
};

function Home({ onNewCustomer, onAddJob }: HomeProps) {
  return (
    <>
      <header className="app-header">
        <h1>WorkBooks</h1>
        <p>Simple books for people who work.</p>
      </header>

      <section className="home">
        <h2>Today</h2>

        <div className="empty-state">
          <p>No jobs scheduled for today.</p>
        </div>

        <div className="home-actions">
          <button
            className="new-customer-button"
            onClick={onNewCustomer}
          >
            + New Customer & Job
          </button>

          <button
            className="add-job-button"
            onClick={onAddJob}
          >
            + Add Job
          </button>
        </div>
      </section>
    </>
  );
}

export default Home;