export type Jobs = {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address: string;
};