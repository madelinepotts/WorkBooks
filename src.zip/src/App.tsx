import { useState } from "react";

import Home from "./pages/Home";
import NewCustomer from "./pages/NewCustomer";
import NewJob from "./pages/NewJob";

import type { Customer } from ".types/Customer";

import "./App.css";

function App() {

  const [screen, setScreen] = useState("home")
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [currentCustomer, setCurrentCustomer] =
    useState<Customer | null>(null);

  return (
    <main className="app">
      {screen === "home" && (
        <Home
          onNewCustomer={() => setScreen("new-customer")}
          onAddJob={() => setScreen("add-job")}
        />
      )}

      {screen === "new-customer" && (
        <NewCustomer
          onCancel={() => setScreen("home")}
          onContinue={(customer) => {
            setCustomers([...customers, customer]);
            setCurrentCustomer(customer);
            setScreen("new-job");
          }}
        />
      )}

      {screen === "new-job" && (
        <NewJob
          onBack={() => setScreen("new-customer")}
          onSave={() => setScreen("home")}
        />
      )}
    </main>
  );
}

export default App;